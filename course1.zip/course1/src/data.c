#include <stdint.h>
#include <stdlib.h>
#include "data.h"



 /*  here the function my_itoa converts data from a standard integer type into an ASCII string.
    All operations are performed using pointer arithmetic arra instead of array indexing
    The number you wish to convert is passed in as a signed 32-bit integer.You should be able to support bases 2 to 16 by specifying the integer value of the base you wish to convert to(base).
    Copy the converted character string to the uint8_t* pointer passed in as a parameter (ptr)
    The signed 32-bit number will have a maximum string size (Hint: Consider base 2).
    You must place a null terminator at the end of the converted c-string
    Function should return the length of the converted data (including a negative sign). Example my_itoa(ptr, 1234, 10) should return an ASCII string length of 5 (including the null          	   terminator).
    This function needs to handle signed data.You may not use any string functions or libraries */
   
uint8_t my_itoa(int32_t data, uint8_t * ptr, uint32_t base)
 {
    //  uint8_t type = 10;
    //  return type;
        uint32_t num;
     if(data < 0)
        num = data + WINT_MAX;

     else
        num = data;

    uint8_t j=0;
    while(num != 0)
    {
        *(ptr+32-j) = num%base;
        num /= base;
        j++;
    }
    ptr = ptr + 33 - j;

    return j;
    }

  /*  here the function my_atoi converts data back from an ASCII  string into an integer type.
    All operations need to be performed using pointer arithmetic, instead of array indexing. The character string which one need to convert in integer is passed in as a uint8_t * pointer  	(ptr). The number of digits in your character set is passed in as a uint8_t integer (digits).
   You should be able to support bases 2 to 16. The converted 32-bit signed integer should be returned. This function is required to handle signed data.
   You may not use any string functions or libraries */
      

int32_t my_atoi(uint8_t *ptr, uint8_t digits, uint32_t base)
{
  int32_t num=0;
  
  for(int i=0;i<digits;i++)
    num = num * base + (*(ptr+i));
    
    if(num < 0)
     num += 1;

   return num;

    }
  
